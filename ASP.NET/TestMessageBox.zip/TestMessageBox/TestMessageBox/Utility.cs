﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Reflection.Emit;
using System.Threading;
using System.Collections;

namespace Jrt.Controls
{
    /// <summary>
    /// 作者:代码乱了(靳如坦)
    /// http://jintan.cnblogs.com
    /// </summary>
    public class Utility
    {
 
        /// <summary>
        /// 构造委托Target在页面的名字
        /// </summary>
        /// <param name="control">控件.</param>
        /// <returns>控件名.</returns>
        public static string GetNameOfWebControl(System.Web.UI.Control control)
        {
            string lTarget = "";
            while (control != control.Page)
            {
                if ((string)lTarget != "") { lTarget = "." + lTarget; }
                if (control.ID + "" == "")
                    lTarget = "#" + control.Parent.Controls.IndexOf(control).ToString() + lTarget;
                else
                    lTarget = control.ID + lTarget;
                control = control.Parent;
            }
            return lTarget;
        }

        /// <summary>
        /// 通过构造的名字获取委托Target所在页面的控件
        /// </summary>
        /// <param name="name">名字.</param>
        /// <returns>控件.</returns>
        public static System.Web.UI.Control GetWebControlByName(string name)
        {
            System.Web.UI.Control lControl = System.Web.HttpContext.Current.Handler as System.Web.UI.Control;
            while ((name != "") && (lControl != null))
            {
                int i = name.IndexOf(".");
                string lid;
                if (i == -1)
                {
                    lid = name;
                    name = "";
                }
                else
                {
                    lid = name.Substring(0, i);
                    name = name.Substring(i + 1);
                }
                if (lid.StartsWith("#"))
                {
                    int lindex = Convert.ToInt32(lid.Substring(1));
                    lControl = lControl.Controls[lindex];
                }
                else
                    lControl = lControl.FindControl(lid);
            }
            if (lControl == null)
                throw new Exception("Control not found (" + name + ").");
            return lControl;
        }
    }
}