﻿using System;
using System.ComponentModel;
using System.Drawing.Design;
using System.Security.Permissions;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Jrt.Controls
{
    /// <summary>
    /// 作者:代码乱了(靳如坦)
    /// http://jintan.cnblogs.com
    /// 实现模仿WinForm的MessageBox控件
    /// </summary>
    [ToolboxData("<{0}:MessageBox runat=\"server\"></{0}:MessageBox>")]
    [System.Serializable(), DesignTimeVisible()]
    public class MessageBox : System.Web.UI.WebControls.WebControl, IPostBackEventHandler
    {
        public MessageBox()
        {
        }

        private string TargetName
        {
            get
            {
                return (String)(ViewState["TargetName"] == null ? string.Empty : ViewState["TargetName"]);
            }
            set
            {
                ViewState["TargetName"] = value;
            }
        }

        private object Data
        {
            get
            {
                return this.Page.Session[GetSessionKey("msgSession")] as object;
            }
            set
            {
                if (value == null)
                {
                    this.Page.Session.Remove(GetSessionKey("msgSession"));
                }
                else
                {
                    this.Page.Session[GetSessionKey("msgSession")] = value;
                }
            }
        }

        private bool cancelPostBack = true;

        //当选择取消的时候是否回传？
        public bool CancelPostBack
        {
            get
            {
                return cancelPostBack;
            }
            set
            {
                cancelPostBack = value;
            }
        }

        //定义响应消息的事件
        public event Message GetMessageBoxResponse;

        //回调处理的委托
        private Message MessageBoxCallBack
        {
            get
            {
                return this.Page.Session[GetSessionKey("MessageBoxCallBack")] as Message;
            }
            set
            {
                if (value == null)
                {
                    this.Page.Session.Remove(GetSessionKey("MessageBoxCallBack"));
                }
                else
                {
                    this.Page.Session[GetSessionKey("MessageBoxCallBack")] = value;
                }
            }
        }

        private string PageIdentify
        {
            get
            {
                if (ViewState["PageIdentify"] == null)
                {
                    ViewState["PageIdentify"] = System.Guid.NewGuid().ToString();
                }
                return ViewState["PageIdentify"].ToString();
            }
        }

        //产生一个控件唯一的Session键
        private string GetSessionKey(string key)
        {
            return key + PageIdentify + this.ClientID;
        }

        //隐藏文本框的Name
        private string HiddenFieldName
        {
            get
            {
                return "hidF" + this.ClientID;
            }
        }

        //消息内容
        private string content;

        public void Alert(string message)
        {
            string msg = message.Replace("\n", "\\n");
            msg = message.Replace("\"", "'");
            StringBuilder sb = new StringBuilder(50);
            sb.Append(@"<script>");
            sb.Append(@"alert( """ + msg + @""" );");
            sb.Append(@"</script>");
            content = sb.ToString();
        }

        public void Show(string message)
        {
            this.Show(message, null);
        }

        public void Show(string message, object data)
        {
            Show(message, data, null);
        }

        public void Show(string message, Message objEventHandler)
        {
            Show(message, null, objEventHandler);
        }

        /// <summary>
        /// 客户端显示confirm的消息框
        /// </summary>
        /// <param name="message">消息内容</param>
        /// <param name="data">要通过GetMessageBoxResponse事件传递的数据.</param>
        public void Show(string message, object data, Message objEventHandler)
        {
            string msg = message.Replace("\n", "\\n");
            msg = message.Replace("\"", "'");

            StringBuilder sb = new StringBuilder(100);
            sb.AppendFormat(@"<input type='hidden' value='{0}' name='" + HiddenFieldName + "' />", DialogResult.NotPressed.ToString());

            StringBuilder sbScript = new StringBuilder(100);
            sbScript.Append(@"<script>");
            sbScript.Append(@" if(confirm( """ + msg + @""" ))");
            sbScript.Append(@" { ");
            sbScript.Append("document.forms[0]." + HiddenFieldName + ".value='" + DialogResult.Yes.ToString() + "';" + Page.ClientScript.GetPostBackEventReference(this, "OK") + " }");
            sbScript.Append(@" else { ");
            sbScript.Append("document.forms[0]." + HiddenFieldName + ".value='" + DialogResult.No.ToString() + "'; ");
            if (cancelPostBack)
            {
                sbScript.Append(Page.ClientScript.GetPostBackEventReference(this, "No"));
            }
            sbScript.Append("}");
            sbScript.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this,this.GetType(),"msgbox", sbScript.ToString(),false);
            //Page.RegisterClientScriptBlock("msgbox", sbScript.ToString());
            content = sb.ToString();
            if (data != null)
            {
                this.Data = data;
            }
            MessageBoxCallBack = objEventHandler;
            if (objEventHandler.Target is Control)
            {
                this.TargetName = Utility.GetNameOfWebControl(objEventHandler.Target as Control);
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            object data = Data;
            MessageBoxEventHandler handler = null;
            DialogResult pressButton = DialogResult.NotPressed;
            if (this.Page.Request.Form[HiddenFieldName] != null && this.Page.Request.Form[HiddenFieldName] != "")
            {
                try
                {
                    pressButton = (DialogResult)Enum.Parse(typeof(DialogResult), this.Page.Request.Form[HiddenFieldName]);
                }
                catch { }
                this.Page.Request.Form[HiddenFieldName].Replace(pressButton.ToString(), DialogResult.NotPressed.ToString());
            }
            if (pressButton != DialogResult.NotPressed)
            {
                handler = new MessageBoxEventHandler(pressButton, data);
                if (handler != null)
                {
                    OnMessageBoxCallBack(handler);
                    OnMessageBoxShow(handler);
                }
            }
            Data = null;

            base.OnLoad(e);
        }

        protected override void Render(HtmlTextWriter output)
        {
            if (!this.DesignMode)
            {
                output.Write(this.content);
            }
            else
            {
                System.Web.UI.WebControls.Label lbl = new Label();
                lbl.Font.Bold = this.Font.Bold;
                lbl.Font.Italic = this.Font.Italic;
                lbl.Font.Names = this.Font.Names;
                lbl.Font.Overline = this.Font.Overline;
                lbl.Font.Size = this.Font.Size;
                lbl.Font.Strikeout = this.Font.Strikeout;
                lbl.Font.Underline = this.Font.Underline;

                lbl.ForeColor = this.ForeColor;
                lbl.BackColor = this.BackColor;
                lbl.BorderColor = this.BorderColor;
                lbl.BorderStyle = this.BorderStyle;
                lbl.BorderWidth = this.BorderWidth;
                lbl.Text = this.ID;
                lbl.RenderControl(output);
            }
            base.Render(output);

        }

        /// <summary>
        /// 执行MessageBoxCallBack回调
        /// </summary>
        /// <param name="e">MessageBox的响应结果返回参数</param>
        private void OnMessageBoxCallBack(MessageBoxEventHandler e)
        {
            if (MessageBoxCallBack != null)
            {
                Object targ = null;
                try
                {
                    if (MessageBoxCallBack.Target is Control)
                    {
                        targ = Utility.GetWebControlByName(this.TargetName);

                        //清空TargetName
                        this.TargetName = "";
                        MessageBoxCallBack.Method.Invoke(targ, new object[] { targ, e });
                    }
                    else
                        MessageBoxCallBack(this, e);
                }
                catch
                {
                    MessageBoxCallBack(this, e);
                }
                MessageBoxCallBack = null;
            }
        }

        /// <summary>
        /// 引发MessageBox的GetMessageBoxResponse事件
        /// </summary>
        /// <param name="e">MessageBox的响应结果返回参数</param>
        protected virtual void OnMessageBoxShow(MessageBoxEventHandler e)
        {
            if (GetMessageBoxResponse != null)
            {
                GetMessageBoxResponse(this, e);
            }
        }


        #region IPostBackEventHandler Members

        public void RaisePostBackEvent(string eventArgument)
        {

        }

        #endregion
    }

    public delegate void Message(object sender, MessageBoxEventHandler e);

    /// <summary>
    /// 响应MessageBox的回调事件
    /// </summary>
    public class MessageBoxEventHandler : System.EventArgs
    {
        public readonly DialogResult Result;
        public readonly object Data;
        public MessageBoxEventHandler(DialogResult buttonPressed)
            : this(buttonPressed, null)
        {
        }
        public MessageBoxEventHandler(DialogResult buttonPressed, object data)
        {
            this.Result = buttonPressed;
            this.Data = data;
        }
    }

    public enum DialogResult
    {
        Yes, No, NotPressed
    }

}
