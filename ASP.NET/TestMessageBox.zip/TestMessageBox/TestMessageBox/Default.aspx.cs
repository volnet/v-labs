﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Jrt.Controls;

namespace TestMessageBox
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //MsgBox是我们封装的服务器控件
            MsgBox.Show("需要删除吗？", (mSender, arg) =>
              {
                  if (arg.Result == DialogResult.Yes)
                  {
                      Label1.Text = "OK，服务器端执行的逻辑结果";
                  }
                  else
                  {
                      Label1.Text = "No，服务器端执行的逻辑结果";
                  }
              }
            );


        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            MsgBox.Show("需要继续导入成绩吗？", DateTime.Now, (mSender, ex) =>
            {
                if (ex.Result == DialogResult.Yes)
                {
                    Label1.Text = "OK，" + ((DateTime)ex.Data).ToShortDateString();
                }
                else
                {
                    Label1.Text = "No，" + ((DateTime)ex.Data).ToShortTimeString();
                }
            }
            );
        }
    }
}
